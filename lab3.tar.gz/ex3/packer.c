#include "packer.h"

// You can declare global variables here

void packer_init(int balls_per_pack) {
    // Write initialization code here (called once at the start of the program).
    // It is guaranteed that balls_per_pack >= 2.
}

void packer_destroy(void) {
    // Write deinitialization code here (called once at the end of the program).
}

void pack_ball(int colour, int id, int *other_ids) {
    // Write your code here.
    // Remember to populate the array `other_ids` with the (balls_per_pack-1) other balls.
}