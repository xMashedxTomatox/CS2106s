#include "packer.h"

// You can declare global variables here

void packer_init(void) {
    // Write initialization code here (called once at the start of the program).
}

void packer_destroy(void) {
    // Write deinitialization code here (called once at the end of the program).
}

int pack_ball(int colour, int id) {
    // Write your code here.

    return 0;
}